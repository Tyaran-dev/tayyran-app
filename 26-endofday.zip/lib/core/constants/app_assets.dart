class AppAssets  {
  static String splashLogo = 'assets/images/splash_logo.png';
  static String onBoarding1 = 'assets/images/onboarding1.png';
  static String onBoarding2 = 'assets/images/onboarding2.png';
  static String onBoarding3 = 'assets/images/onboarding3.png';

}