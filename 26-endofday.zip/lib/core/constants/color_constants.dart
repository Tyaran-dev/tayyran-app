import 'package:flutter/material.dart';

class AppColors {
  static const Color splashBackgroundColorStart = Color(0xFF1C1466);
  static const Color splashBackgroundColorEnd = Color(0xFF016733);

}
