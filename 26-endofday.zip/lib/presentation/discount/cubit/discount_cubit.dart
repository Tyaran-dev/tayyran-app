import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tayyran_app/presentation/discount/cubit/discount_state.dart';

class DiscountCubit extends Cubit<DiscountState> {
  DiscountCubit() : super(DiscountState.initial());

  // Add bookings-specific logic
}
