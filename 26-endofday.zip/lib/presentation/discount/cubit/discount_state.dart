import 'package:flutter/material.dart';

@immutable
class DiscountState {
  const DiscountState();

  static DiscountState initial() {
    return const DiscountState();
  }
}
