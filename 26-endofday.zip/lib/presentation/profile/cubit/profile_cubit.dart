import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tayyran_app/presentation/profile/cubit/profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit() : super(ProfileState.initial());

  // Add bookings-specific logic
}
