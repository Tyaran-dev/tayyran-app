import 'package:flutter/material.dart';

@immutable
class ProfileState {
  const ProfileState();

  static ProfileState initial() {
    return const ProfileState();
  }
}
