part of 'booking_cubit.dart';

@immutable
class BookingState {
  const BookingState();

  static BookingState initial() {
    return const BookingState();
  }
}
